# aeroplane-crash
This project is a simple animation that shows an aeroplane crash using OpenGL, a computer graphics library that provides a set of functions for creating 2D and 3D graphics. The animation demonstrates the use of basic OpenGL concepts such as drawing shapes and textures to create an engaging visual experience.
